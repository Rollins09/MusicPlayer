/* ---------- SONG DATA ---------- */
// Array of all songs in the player
const allSongs = [
  {
    title: "Bekhayali", // Song title
    artist: "Parampara Irshad", // Artist name
    album: "2019 Hindi Film Kabir Singh", // Album info
    src: "./assets/songs/Bekhayali Full Song  Kabir Singh  Shahid K,Kiara ASandeep Reddy Vanga  Sachet-Parampara  Irshad.mp3", // Audio file path
    cover: "./assets/covers/Bekhayali.jpg" // Cover image path
  },
  {
    title: "Dewane hum nhi hote",
    artist: "Asira Aarya Chakradhari",
    album: "Hindi album released on 29 June 2022",
    src: "./assets/songs/Deewane Hum Nahi Hote (Slow and Reverb)  Lofi  Hindi - (Slow and Reverb) songs  Lyrical Audio.mp3",
    cover: "./assets/covers/Deewane-Hum-Nahi-Hote.jpg"
  },
  {
    title: "Dope Shope",
    artist: "Honey Singh",
    album: "International Villager 2011",
    src: "./assets/songs/Dope Shope   Yo Yo Honey Singh and Deep Money   Brand New Punjabi Songs HD   International Villager.mp3",
    cover: "./assets/covers/dope-shope.jpg"
  },
  {
    title: "Horn BLow",
    artist: "Hardy Sandhu",
    album: "2016 punjabi album This is Hardy Sandhu",
    src: "./assets/songs/Hardy Sandhu_ HORNN BLOW Video Song  Jaani  B Praak  New Song 2016  T-Series.mp3",
    cover: "./assets/covers/horn-blow.jpg"
  },
  {
    title: "Love Dose",
    artist: "Honey Singh",
    album: "Desi Kalakaar",
    src: "./assets/songs/Exclusive_ LOVE DOSE Full Video Song  Yo Yo Honey Singh, Urvashi Rautela  Desi Kalakaar.mp3",
    cover: "./assets/covers/love-dose.jpg"
  },
  {
    title: "Jeena Jeena",
    artist: "Atif Aslam",
    album: "2015 Hindi film Badlapur",
    src: "./assets/songs/Jeena Jeena - ( Slowed  Reverb )  Ear Candy.mp3",
    cover: "./assets/covers/Jeena_Jeena.jpeg"
  },
  {
    title: "Main rang sharbaton ka",
    artist: "Arijit Singh",
    album: "2013 Hindi film Phata Poster Nikhla Hero",
    src: "./assets/songs/Main Rang Sharbaton Ka - Arijit Singh ( Slowed And Reverb ).mp3",
    cover: "./assets/covers/rang sarbato.jpg"
  },
  {
    title: "Samjhawan",
    artist: "Arijit Singh, Shreya Ghoshal",
    album: "2014 Hindi film Humpty Sharma Ki Dulhania",
    src: "./assets/songs/Samjhawan [SlowedReverb] -Arijit Singh, Shreya Ghoshal  Nexus Music.mp3",
    cover: "./assets/covers/samjhawa.jpg"
  },
  {
    title: "Sun Saathiya Maahiya",
    artist: "Priya Saraiya, Divya Kumar",
    album: "2018 Hindi Film ABCD 2",
    src: "./assets/songs/Sun Saathiya Maahiya [Slowed Reverb] ABCD 2  Priya Saraiya, Divya Kumar  Srk Lofi World.mp3",
    cover: "./assets/covers/Sun-Saathiya.jpg"
  }
];

/* ---------- STATE VARIABLES ---------- */
let playlistSongs = [...allSongs]; // Current playlist (can be shuffled)
let currentIndex = 0; // Index of currently playing song
let isShuffle = false; // Shuffle mode flag
let isRepeat = false; // Repeat mode flag
let likedSongs = []; // Array to store liked songs

/* ---------- DOM ELEMENTS ---------- */
const audio = document.getElementById("audio"); // Audio element
const songTitle = document.getElementById("songTitle"); // Song title display
const artist = document.getElementById("artist"); // Artist display
const infoSong = document.getElementById("infoSong"); // Song info in panel
const infoAlbum = document.getElementById("infoAlbum"); // Album info in panel
const cover = document.getElementById("cover"); // Cover image
const playlist = document.getElementById("playlist"); // Playlist container
const playBtn = document.getElementById("playBtn"); // Play/pause button
const progress = document.getElementById("progress"); // Progress slider
const volume = document.getElementById("volume"); // Volume slider
const currentTimeEl = document.getElementById("currentTime"); // Current time display
const durationEl = document.getElementById("duration"); // Total duration display
const likeBtn = document.getElementById("likeBtn"); // Like button
const shuffleBtn = document.getElementById("shuffleBtn"); // Shuffle button
const repeatBtn = document.getElementById("repeatBtn"); // Repeat button

/* ---------- LOAD SONG ---------- */
function loadSong(index) {
  const s = playlistSongs[index]; // Get song from playlist
  audio.src = s.src; // Set audio source

  songTitle.textContent = s.title; // Update title
  artist.textContent = s.artist; // Update artist
  infoSong.textContent = s.title; // Update song info
  infoAlbum.textContent = s.album || "Single"; // Update album info
  cover.src = s.cover; // Update cover image

  highlightActiveSong(); // Highlight currently playing song in playlist
  updateLike(); // Update like button based on liked songs
}

/* ---------- PLAY / PAUSE ---------- */
function playPause() {
  audio.paused ? audio.play() : audio.pause(); // Toggle play/pause
}

// Change play button icon depending on state
audio.onplay = () => playBtn.textContent = "⏸"; // Pause icon when playing
audio.onpause = () => playBtn.textContent = "▶"; // Play icon when paused

/* ---------- NEXT / PREVIOUS ---------- */
function next() {
  if (isRepeat) { // If repeat mode
    audio.currentTime = 0; // Restart current song
    audio.play();
    return;
  }

  if (isShuffle) { // If shuffle mode
    let newIndex;
    do {
      newIndex = Math.floor(Math.random() * playlistSongs.length); // Random index
    } while (newIndex === currentIndex); // Ensure not same song
    currentIndex = newIndex;
  } else { // Normal mode
    currentIndex = (currentIndex + 1) % playlistSongs.length; // Next song in loop
  }

  loadSong(currentIndex); // Load next song
  audio.play(); // Start playing
}

function prev() {
  currentIndex =
    (currentIndex - 1 + playlistSongs.length) % playlistSongs.length; // Previous song in loop
  loadSong(currentIndex); // Load previous song
  audio.play(); // Start playing
}

/* ---------- BUILD PLAYLIST ---------- */
function buildPlaylist() {
  playlist.innerHTML = ""; // Clear existing list

  playlistSongs.forEach((song, index) => {
    const li = document.createElement("li"); // Create list item
    li.textContent = `${song.title} — ${song.artist}`; // Display title & artist

    li.onclick = () => { // Click to play song
      currentIndex = index;
      loadSong(index);
      audio.play();
    };

    playlist.appendChild(li); // Add to playlist container
  });

  highlightActiveSong(); // Highlight active song
}

/* ---------- HIGHLIGHT ACTIVE SONG ---------- */
function highlightActiveSong() {
  const items = playlist.querySelectorAll("li"); // Get all list items

  items.forEach((li, index) => {
    li.classList.toggle("active", index === currentIndex); // Add active class
  });

  const activeItem = items[currentIndex];
  if (!activeItem) return;

  // Scroll playlist to center active song
  const containerRect = playlist.getBoundingClientRect();
  const itemRect = activeItem.getBoundingClientRect();

  const offset =
    itemRect.top - containerRect.top +
    playlist.scrollTop -
    playlist.clientHeight / 2 +
    activeItem.clientHeight / 2;

  playlist.scrollTo({
    top: offset,
    behavior: "smooth" // Smooth scrolling
  });
}

/* ---------- TIME & PROGRESS CONTROL ---------- */
audio.ontimeupdate = () => {
  if (!audio.duration) return; // Skip if no duration
  progress.value = (audio.currentTime / audio.duration) * 100; // Update progress bar
  currentTimeEl.textContent = formatTime(audio.currentTime); // Update current time
};

audio.onloadedmetadata = () => {
  durationEl.textContent = formatTime(audio.duration); // Set total duration
};

audio.onended = next; // Auto-play next song when current ends

progress.oninput = () => {
  audio.currentTime = (progress.value / 100) * audio.duration; // Seek song
};

volume.oninput = () => {
  audio.volume = volume.value; // Adjust volume
};

/* ---------- LIKE / SHUFFLE / REPEAT ---------- */
function updateLike() {
  likeBtn.textContent = likedSongs.includes(songTitle.textContent)
    ? "❤️" // Filled heart if liked
    : "♡"; // Empty heart if not liked
}

likeBtn.onclick = () => {
  const t = songTitle.textContent;
  likedSongs.includes(t)
    ? likedSongs = likedSongs.filter(x => x !== t) // Remove from liked
    : likedSongs.push(t); // Add to liked
  updateLike(); // Refresh like button
};

shuffleBtn.onclick = () => {
  isShuffle = !isShuffle; // Toggle shuffle
  shuffleBtn.classList.toggle("active", isShuffle); // Update button style
};

repeatBtn.onclick = () => {
  isRepeat = !isRepeat; // Toggle repeat
  repeatBtn.classList.toggle("active", isRepeat); // Update button style
};

/* ---------- UTILITIES ---------- */
function formatTime(sec) {
  const m = Math.floor(sec / 60); // Minutes
  const s = Math.floor(sec % 60).toString().padStart(2, "0"); // Seconds with leading zero
  return `${m}:${s}`; // Return formatted string
}

/* ---------- INITIALIZATION ---------- */
audio.volume = 0.7; // Default volume
buildPlaylist(); // Build playlist UI
loadSong(currentIndex); // Load first song
